var brandModel = require('../models/brand');

var ObjectId = require('mongodb').ObjectId;

module.exports = 
{
	index: function(req, res, next)
	{
		res.render('brand-add');
	},
	indexPost: function(req, res, next) 
	{
		console.log(req.body);

		var { name } = req.body;

		var errors = [];
		
		if(!name)
		{
			errors.push('You forget some fields :(');
		}

		if(errors.length > 0)
		{
			res.render('brand-add', 
			{
				errors: errors,
				values: req.body
			});
		}
		else
		{
			var newBrand =
			{
				name: name,
				didDelete: false
			};
			brandModel.insertBrand(newBrand, function(result)
			{
				req.flash('success_msg', 'Inserted successful :)');

	            res.redirect('/brand-add.html');
			});
		}
	}
};