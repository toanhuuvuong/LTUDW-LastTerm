var productModel = require('../models/product');
var stallModel = require('../models/stall');
var brandModel = require('../models/brand');

var ObjectId = require('mongodb').ObjectId;

module.exports = 
{
	index: function(req, res, next)
	{
		var _id = req.query._id;

		productModel.getListProductByQuery({ _id: ObjectId(_id) }, function(products)
		{
			stallModel.getListStallByQuery({}, function(stalls)
			{
				brandModel.getListBrandByQuery({}, function(brands)
				{
					res.render('product-edit', 
					{
						product: products[0],
						stalls: stalls,
						brands: brands
					});
				});
			});
		});
	},
	indexPost: function(req, res, next) 
	{
		console.log(req.body);

		var _id = req.query._id;
		var { stallId, brandId, name, oldPrice, price, qtyInStock, description } = req.body;
		var image = req.file ? req.file.path.split('/').slice(1).join('/') : '';
		var errors = [];

		if(!name || image=='' || !oldPrice || !price || !qtyInStock || !description)
		{
			errors.push('You forget some fields :(');
		}

		if(errors.length > 0)
		{
			productModel.getListProductByQuery({ _id: ObjectId(_id) }, function(products)
			{
				stallModel.getListStallByQuery({}, function(stalls)
				{
					brandModel.getListBrandByQuery({}, function(brands)
					{
						res.render('product-edit', 
						{
							product: products[0],
							stalls: stalls,
							brands: brands,
							errors: errors,
							values: req.body
						});
					});
				});
			});
		}
		else
		{

			productModel.updateProduct({ _id: ObjectId(_id) }, { $set: { stallId: stallId, brandId: brandId, name: name, image: image, oldPrice: oldPrice, price: price, qtyInStock: qtyInStock, description: description } }, function(result)
			{
				req.flash('success_msg', 'Updated successful :)');

	            res.redirect('/product-edit.html?_id=' + _id);
			});
		}
	}
};