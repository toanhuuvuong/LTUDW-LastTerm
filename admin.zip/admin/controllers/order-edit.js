var orderModel = require('../models/order');
var orderDetailModel = require('../models/order-detail');
var customerModel = require('../models/customer');
var productModel = require('../models/product');

var ObjectId = require('mongodb').ObjectId;

module.exports = 
{
	index: function(req, res, next)
	{
		var { _id, startPage, page, perPage } = req.query;

		startPage = (startPage == undefined) ? 1 : parseInt(startPage);
		page = (page == undefined) ? 1 : parseInt(page);
		perPage = (perPage == undefined) ? 10 : parseInt(perPage);

		var start = (page - 1) * perPage;
		var end = page * perPage;

		orderModel.getListOrderByQuery({ _id: ObjectId(_id) }, function(orders)
		{
			customerModel.getListCustomerByQuery({ _id: ObjectId(orders[0].customerId) }, function(customers)
			{
				orderDetailModel.getListOrderDetailByQuery({ orderId: _id }, function(orderDetails)
				{
					var productIds = [];

					for(var orderDetail of orderDetails)
					{
						productIds.push(ObjectId(orderDetail.productId));
					}

					productModel.getListProductByQuery({ _id: { $in: productIds } }, function(products)
					{
						res.render('order-edit', 
						{
							order: orders[0],
							customer: customers[0],
							orderDetails: orderDetails.slice(start, end),
							products: products,
							startPage: startPage,
							page: page,
							perPage: perPage
						});
					});
				});
			});
		});
	},
	indexPost: function(req, res, next) 
	{
		console.log(req.body);

		var { _id, startPage, page, perPage } = req.query;
		var { status, didDelete } = req.body;

		orderModel.updateOrder({ _id: ObjectId(_id) }, { $set: { status: status, didDelete: (didDelete=='true') } }, function(result)
		{
			req.flash('success_msg', 'Updated successful :)');

            res.redirect('/order-edit.html?_id=' + _id);
		});
	}
};