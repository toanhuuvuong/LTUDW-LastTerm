var adminModel = require('../models/admin');
var bcrypt = require('bcryptjs');

module.exports =
{
	index: function(req, res, next)
	{
		res.render('registration');
	},
	indexPost: function(req, res, next) 
	{
		console.log(req.body);
		
		var { name, phone, gender, birth, email, password1, password2 } = req.body;

		var errors = [];

		if(!name || !phone || !birth || !email || !password1 || !password2)
		{
			errors.push('You forget some fields :(');
		}
		if(password1 != password2)
		{
			errors.push('Your password do not match :(');
		}
		if(password1.length <= 6)
		{
			errors.push('Your password must be at least 7 characters :(');
		}

		if(errors.length > 0)
		{
			res.render('registration', 
			{
				errors: errors,
				values: req.body
			});
		}
		else
		{
			adminModel.getListAdminByQuery({ email: email }, function(admins)
			{
				var admin = admins[0];

				if(admin)
				{
					errors.push('Email already exists :(');
			    	res.render('registration', 
					{
						errors: errors,
						values: req.body
					});
				}
				else
				{
					var newAdmin = 
					{
						name: name,
						phone: phone,
						gender: gender,
						birth: birth,
						email: email,
						password: password1,
						didDelete: false
					}

					bcrypt.genSalt(10, function(err, salt)
					{
				        bcrypt.hash(newAdmin.password, salt, function(err, hash)
				        {
				            if (err) throw err;

				            newAdmin.password = hash;

				            adminModel.insertAdmin(newAdmin, function(result)
				            {
				            	req.flash('success_msg', 'Registered successful :)');

				              	res.redirect('registration.html');
				            });
		        		});
		  			});
				}
			});
		}
	},
	checkTheHighestAdmin: function(req, res, next)
	{
		if(req.user.email == 'toanhuuvuong.com@gmail.com')
		{
			next();
		}
		res.redirect('/');
	}
};