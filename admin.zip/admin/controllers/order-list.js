var orderModel = require('../models/order');
var customerModel = require('../models/customer');

var ObjectId = require('mongodb').ObjectId;

module.exports = 
{
	index: function(req, res, next)
	{
		var { startPage, page, perPage } = req.query;

		startPage = (startPage == undefined) ? 1 : parseInt(startPage);
		page = (page == undefined) ? 1 : parseInt(page);
		perPage = (perPage == undefined) ? 10 : parseInt(perPage);

		var start = (page - 1) * perPage;
		var end = page * perPage;
  
		orderModel.getListOrderByQuery({}, function(orders)
		{
			var customerIds = [];
			
			for(var order of orders)
			{
				customerIds.push(ObjectId(order.customerId));
			}

			customerModel.getListCustomerByQuery({ _id: { $in: customerIds } }, function(customers)
			{
				res.render('order-list',
				{
					orders: orders.slice(start, end),
					customers: customers,
					startPage: startPage,
					page: page,
					perPage: perPage
				});
			});
		});
		
	}
};