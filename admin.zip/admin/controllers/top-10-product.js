module.exports = 
{
	index: function(req, res, next)
	{
		res.render('top-10-product');
	}
};