var userModel = require('../models/user');

var ObjectId = require('mongodb').ObjectId;

module.exports = 
{
	index: function(req, res, next)
	{
		var _id = req.query._id;

		userModel.getListUserByQuery({ _id: ObjectId(_id) }, function(users)
		{
			res.render('account-edit', 
			{
				user: users[0]
			});
		});
	},
	indexPost: function(req, res, next) 
	{
		console.log(req.body);

		var _id = req.query._id;
		var { didDelete } = req.body;

		userModel.updateUser({ _id: ObjectId(_id) }, { $set: { didDelete: (didDelete=='true') } }, function(result)
		{
			req.flash('success_msg', 'Updated successful :)');

            res.redirect('/account-edit.html?_id=' + _id);
		});
	}
};