var express = require('express');
var controller = require("../controllers/update-admin-info.js");
var authentication = require('../config/authentication');

var router = express.Router();

/* GET update-admin-info page. */
router.get('/', authentication.ensureAuthenticated, controller.index);

/* POST update-admin-info page. */
router.post('/', controller.indexPost);

module.exports = router;