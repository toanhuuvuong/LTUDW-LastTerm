var baseQuery = require("./base-query");

module.exports = 
{
		// -- Cập nhật 1 nhãn hiệu
	updateBrand: function(query, newValue, callback)
	{
		baseQuery.updateDocument("Brand", query, newValue, callback)
	},
	// -- Thêm 1 nhãn hiệu
	insertBrand: function(newBrand, callback)
	{
		baseQuery.insertDocument("Brand", newBrand, callback)
	},
	// -- Lấy danh sách nhãn hiệu theo câu truy vấn
	getListBrandByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Brand", query, callback, options)
	}
};