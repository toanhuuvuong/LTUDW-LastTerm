var baseQuery = require("./base-query");

module.exports = 
{
	// -- Cập nhật 1 sản phẩm
	updateProduct: function(query, newValue, callback)
	{
		baseQuery.updateDocument("Product", query, newValue, callback)
	},
	// -- Thêm 1 sản phẩm
	insertProduct: function(newProduct, callback)
	{
		baseQuery.insertDocument("Product", newProduct, callback)
	},
	// -- Lấy danh sách sản phẩm theo câu truy vấn
	getListProductByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Product", query, callback, options)
	}
};