var baseQuery = require("./base-query");

module.exports = 
{
	// -- Cập nhật 1 gian hàng
	updateStall: function(query, newValue, callback)
	{
		baseQuery.updateDocument("Stall", query, newValue, callback)
	},
	// -- Thêm 1 gian hàng
	insertStall: function(newStall, callback)
	{
		baseQuery.insertDocument("Stall", newStall, callback)
	},
	// -- Lấy danh sách gian hàng theo câu truy vấn
	getListStallByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Stall", query, callback, options)
	}
};