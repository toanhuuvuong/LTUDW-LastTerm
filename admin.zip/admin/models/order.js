var baseQuery = require("./base-query");

module.exports = 
{
	// -- Cập nhật 1 đơn hàng
	updateOrder: function(query, newValue, callback)
	{
		baseQuery.updateDocument("Order", query, newValue, callback)
	},
	// -- Thêm 1 đơn hàng
	insertOrder: function(newOrder, callback)
	{
		baseQuery.insertDocument("Order", newOrder, callback)
	},
	// -- Lấy danh sách đơn hàng theo câu truy vấn
	getListOrderByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Order", query, callback, options)
	}
};