var baseQuery = require("./base-query");

module.exports = 
{
	// -- Cập nhật 1 người dùng
	updateUser: function(query, newValue, callback)
	{
		baseQuery.updateDocument("User", query, newValue, callback)
	},
	// -- Thêm 1 người dùng
	insertUser: function(newUser, callback)
	{
		baseQuery.insertDocument("User", newUser, callback)
	},
	// -- Lấy danh sách người dùng theo câu truy vấn
	getListUserByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("User", query, callback, options)
	}
};