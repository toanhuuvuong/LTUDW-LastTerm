var brandModel = require('../models/brand');

module.exports = 
{
	index: function(req, res, next)
	{
		var { startPage, page, perPage } = req.query;

		startPage = (startPage == undefined) ? 1 : parseInt(startPage);
		page = (page == undefined) ? 1 : parseInt(page);
		perPage = (perPage == undefined) ? 10 : parseInt(perPage);

		var start = (page - 1) * perPage;
		var end = page * perPage;
  
		brandModel.getListBrandByQuery({}, function(brands)
		{
			res.render('brand-list',
			{
				brands: brands.slice(start, end),
				startPage: startPage,
				page: page,
				perPage: perPage
			});
		});
		
	}
};