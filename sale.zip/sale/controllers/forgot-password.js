var userModel = require('../models/user');

module.exports =
{
	index: function(req, res, next)
	{
		res.render('forgot-password');
	},
	indexPost: function(req, res, next)
	{
		console.log(req.body);
		
		var { email } = req.body;

		var errors = [];

		if(!email)
		{
			errors.push('You forget some fields :(');
		}

		if(errors.length > 0)
		{
			res.render('forgot-password', 
			{
				errors: errors,
				values: req.body
			});
		}
		else
		{
			userModel.getListUserByQuery({ email: email }, function(users)
			{
				var user = users[0];

				if(!user)
				{
					errors.push('That email is not registered :(');
			    	res.render('forgot-password', 
					{
						errors: errors,
						values: req.body
					});
				}
				else
				{
				    res.redirect('/renew-password.html?email='+email);
				}
			});
		}
	}
};