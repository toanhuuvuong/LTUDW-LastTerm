module.exports =
{
	index: function(req, res, next)
	{
		res.render('forgot-password-1');
	},
	indexPost: function(req, res, next)
	{
		res.render('forgot-password-1');
	},
	changePassword: function(req, res, next)
	{
		res.render('forgot-password-2');
	},
	postChangePassword: function(req, res, next)
	{
		res.render('forgot-password-2');
	}
};