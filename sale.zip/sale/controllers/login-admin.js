var passport = require('passport');

module.exports =
{
	index: function(req, res, next)
	{
		res.render('login-admin');
	},
	indexPost: function(req, res, next)
	{
		process.env.LOGIN_TYPE = 'admin';
		
		passport.authenticate('local', 
		{
		    successRedirect: 'home.html',
		    failureRedirect: 'login-admin.html',
		    failureFlash: true
	  	})(req, res, next);
	}
};
