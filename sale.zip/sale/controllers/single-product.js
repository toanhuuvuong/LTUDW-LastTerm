var productModel = require('../models/product');
var reviewModel = require('../models/review');
var userModel = require('../models/user');
var brandModel = require('../models/brand');

var ObjectId = require('mongodb').ObjectId;
var Cart = require('../models/cart');

module.exports =
{
	index: function(req, res, next) 
	{
		var { _id, startPage, page, perPage } = req.query;

		startPage = (startPage == undefined) ? 1 : parseInt(startPage);
		page = (page == undefined) ? 1 : parseInt(page);
		perPage = (perPage == undefined) ? 3 : parseInt(perPage);

		var start = (page - 1) * perPage;
		var end = page * perPage;

		productModel.getListProductByQuery({ _id: ObjectId(_id) }, function(products)
		{
			var product = products[0];

			productModel.updateProduct({ _id: ObjectId(_id) }, { $set: { numView: product.numView + 1 } } , function(result)
			{
				reviewModel.getListReviewByQuery({ productId: _id }, function(reviews)
				{
					brandModel.getListBrandByQuery({ _id: ObjectId(product.brandId) }, function(brands)
					{
						res.render('single-product', 
						{
							product: product,
							productBrand: brands[0].name,
							reviews: reviews.slice(start, end),
							startPage: startPage,
							page: page,
							perPage: perPage
						});
					});
				});
			});
		});
	},
	indexPost: function(req, res, next) 
	{
		console.log(req.body);
		
		var { email, name, comment, rating } = req.body;

		var { _id, startPage, page, perPage } = req.query;

		startPage = (startPage == undefined) ? 1 : parseInt(startPage);
		page = (page == undefined) ? 1 : parseInt(page);
		perPage = (perPage == undefined) ? 3 : parseInt(perPage);

		var start = (page - 1) * perPage;
		var end = page * perPage;

		var errors = [];

		if(!comment || !rating)
		{
			errors.push('You forget some fields :(');
			productModel.getListProductByQuery({ _id: ObjectId(_id) }, function(products)
			{
				reviewModel.getListReviewByQuery({ productId: _id }, function(reviews)
				{
					brandModel.getListBrandByQuery({ _id: ObjectId(products[0].brandId) }, function(brands)
					{
						res.render('single-product', 
						{
							product: products[0],
							productBrand: brands[0].name,
							reviews: reviews.slice(start, end),
							startPage: startPage,
							page: page,
							perPage: perPage,
							errors: errors,
							values: req.body
						});
					});
				});
			});
		}
		else
		{
			if(!email || !name)
			{
				if(process.env.DID_LOGIN == 'FALSE')
				{
					errors.push('You forget some fields :(');
					productModel.getListProductByQuery({ _id: ObjectId(_id) }, function(products)
					{
						reviewModel.getListReviewByQuery({ productId: _id }, function(reviews)
						{
							brandModel.getListBrandByQuery({ _id: ObjectId(products[0].brandId) }, function(brands)
							{
								res.render('single-product', 
								{
									product: products[0],
									productBrand: brands[0].name,
									reviews: reviews.slice(start, end),
									startPage: startPage,
									page: page,
									perPage: perPage,
									errors: errors,
									values: req.body
								});
							});
						});
					});
				}
				else
				{
					userModel.getListUserByQuery({ email: req.user.email }, function(users)
					{
						email = users[0].email;
						name = users[0].name;

						var today = new Date();
						var dd = String(today.getDate()).padStart(2, '0');
						var mm = String(today.getMonth() + 1).padStart(2, '0');
						var yyyy = today.getFullYear();
						today = mm + '-' + dd + '-' + yyyy;

						var newReview = 
						{
							productId: _id,
							email: email,
							name: name,
							rating: parseInt(rating),
							comment: comment,
							commentedDate: today,
							didDelete: false
						}

						reviewModel.insertReview(newReview, function(result)
						{
							productModel.getListProductByQuery({ _id: ObjectId(_id) }, function(products)
							{ 
								var numRate = products[0].numRate + 1;
								var ratingStart = (products[0].ratingStart * products[0].numRate + newReview.rating) / numRate;
								
								productModel.updateProduct({ _id: ObjectId(_id) }, { $set: { ratingStart: ratingStart, numRate: numRate } }, function(result)
								{
									req.flash('success_msg', 'Review successful :)');
									res.redirect('/single-product.html?_id=' + _id + '&startPage=' + startPage + '&page=' + page + '&perPage=' + perPage);
								});
							});
						});
					});
				}
			}
			else
			{
				var today = new Date();
				var dd = String(today.getDate()).padStart(2, '0');
				var mm = String(today.getMonth() + 1).padStart(2, '0');
				var yyyy = today.getFullYear();
				today = mm + '-' + dd + '-' + yyyy;

				var newReview = 
				{
					productId: _id,
					email: email,
					name: name,
					rating: parseInt(rating),
					comment: comment,
					commentedDate: today,
					didDelete: false
				}

				reviewModel.insertReview(newReview, function(result)
				{
					productModel.getListProductByQuery({ _id: ObjectId(_id) }, function(products)
					{ 
						var numRate = products[0].numRate + 1;
						var ratingStart = (products[0].ratingStart * products[0].numRate + newReview.rating) / numRate;
						
						productModel.updateProduct({ _id: ObjectId(_id) }, { $set: { ratingStart: ratingStart, numRate: numRate } }, function(result)
						{
							req.flash('success_msg', 'Review successful :)');
							res.redirect('/single-product.html?_id=' + _id + '&startPage=' + startPage + '&page=' + page + '&perPage=' + perPage);
						});
					});
				});
			}
		}
	},
	addToCart: function(req, res, next)
	{
		productModel.getListProductByQuery({ _id: ObjectId(req.query._id) }, function(products)
		{
			var product = products[0];
			var cart = new Cart((req.session.cart) ? req.session.cart : {});

			cart.add(product, product._id, parseInt(req.query.qty));

			req.session.cart = cart;

			console.log(req.session.cart);

			res.redirect('/single-product.html?_id='+product._id);
		});
	}
};