var productModel = require('../models/product');
var reviewModel = require('../models/review');
var userModel = require('../models/user');

var ObjectId = require('mongodb').ObjectId;
var Cart = require('../models/cart');

module.exports =
{
	index: function(req, res, next) 
	{
		productModel.getListProductByQuery({ _id: ObjectId(req.query._id) }, function(products)
		{
			reviewModel.getListReviewByQuery({ productId: req.query._id }, function(reviews)
			{
				res.render('single-product', 
				{
					product: products[0],
					reviews: reviews
				});
			});
		});
	},
	indexPost: function(req, res, next) 
	{
		console.log(req.body);
		
		var { email, name, comment, rating } = req.body;

		var productId = req.query._id;

		var errors = [];

		if(!comment || !rating)
		{
			errors.push('You forget some fields :(');
			productModel.getListProductByQuery({ _id: ObjectId(req.query._id) }, function(products)
			{
				reviewModel.getListReviewByQuery({ productId: req.query._id }, function(reviews)
				{
					res.render('single-product', 
					{
						product: products[0],
						reviews: reviews,
						errors: errors,
						values: req.body
					});
				});
			});
		}
		else
		{
			if(!email || !name)
			{
				if(process.env.DID_LOGIN == 'FALSE')
				{
					errors.push('You forget some fields :(');
					productModel.getListProductByQuery({ _id: ObjectId(req.query._id) }, function(products)
					{
						reviewModel.getListReviewByQuery({ productId: req.query._id }, function(reviews)
						{
							res.render('single-product', 
							{
								product: products[0],
								reviews: reviews,
								errors: errors,
								values: req.body
							});
						});
					});
				}
				else
				{
					userModel.getListUserByQuery({ email: req.user.email }, function(users)
					{
						email = users[0].email;
						name = users[0].name;

						var today = new Date();
						var dd = String(today.getDate()).padStart(2, '0');
						var mm = String(today.getMonth() + 1).padStart(2, '0');
						var yyyy = today.getFullYear();
						today = mm + '-' + dd + '-' + yyyy;

						var newReview = 
						{
							productId: productId,
							email: email,
							name: name,
							rating: parseInt(rating),
							comment: comment,
							commentedDate: today,
							didDelete: false
						}

						reviewModel.insertReview(newReview, function(result)
						{ 
							req.flash('success_msg', 'Review successful :)');
							res.redirect('/single-product.html?_id=' + productId);
						});
					});
				}
			}
			else
			{
				var today = new Date();
				var dd = String(today.getDate()).padStart(2, '0');
				var mm = String(today.getMonth() + 1).padStart(2, '0');
				var yyyy = today.getFullYear();
				today = mm + '-' + dd + '-' + yyyy;

				var newReview = 
				{
					productId: productId,
					email: email,
					name: name,
					rating: parseInt(rating),
					comment: comment,
					commentedDate: today,
					didDelete: false
				}

				reviewModel.insertReview(newReview, function(result)
				{ 
					req.flash('success_msg', 'Review successful :)');
					res.redirect('/single-product.html?_id=' + productId);
				});
			}
		}
	},
	addToCart: function(req, res, next)
	{
		productModel.getListProductByQuery({ _id: ObjectId(req.query._id) }, function(products)
		{
			var product = products[0];
			var cart = new Cart((req.session.cart) ? req.session.cart : {});

			cart.add(product, product._id, parseInt(req.query.qty));

			req.session.cart = cart;

			console.log(req.session.cart);

			res.redirect('/single-product.html?_id='+product._id);
		});
	}
};