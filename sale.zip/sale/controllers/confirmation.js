var customerModel = require('../models/customer');
var orderModel = require('../models/order');

var ObjectId = require('mongodb').ObjectId;
var Cart = require('../models/cart');

module.exports =
{
	index: function(req, res, next)
	{
		var _id = req.query._id;

		if(!_id)
		{
			res.redirect('index.html');
		}
		else
		{
			orderModel.getListOrderByQuery({ _id: ObjectId(_id) }, function(orders)
			{
				if(orders.length==0)
				{
					res.redirect('index.html');
				}
				else
				{
					var order = orders[0];

					var cart = new Cart((req.session.cart) ? req.session.cart : {});

					customerModel.getListCustomerByQuery({ _id: ObjectId(order.customerId) }, function(customers)
					{
						var customer = customers[0];

						res.render('confirmation', 
						{
							storedItems: cart.generateArray(),
							totalPrice: cart.totalPrice,
							order: order,
							customer: customer
						});
					});
				}
			});	
		}
	}
};