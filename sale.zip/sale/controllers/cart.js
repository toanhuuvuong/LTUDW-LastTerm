var Cart = require('../models/cart');

module.exports= 
{
	index: function(req, res, next)
	{
		var cart = new Cart((req.session.cart) ? req.session.cart : {});
		
		res.render('cart', 
		{
			storedItems: cart.generateArray(),
			totalQty: cart.totalQty,
			totalPrice: cart.totalPrice
		});
	},
	removeItem: function(req, res, next)
	{
		var cart = new Cart((req.session.cart) ? req.session.cart : {});

		cart.remove(req.query._id);

		req.session.cart = cart;

		res.redirect('/cart.html');
	},
	updateCart: function(req, res, next)
	{

	}
};