var Cart = require('../models/cart');

module.exports= 
{
	index: function(req, res, next)
	{
		var cart = new Cart((req.session.cart) ? req.session.cart : {});
		
		res.render('cart', 
		{
			storedItems: cart.generateArray(),
			totalQty: cart.totalQty,
			totalPrice: cart.totalPrice
		});
	},
	indexPost: function(req, res, next) 
	{
		console.log(req.body);
		
		var { qtys } = req.body;

		var cart = new Cart((req.session.cart) ? req.session.cart : {});

		cart.update(qtys);

		req.session.cart = cart;

		res.redirect('cart.html');
	},
	removeItem: function(req, res, next)
	{
		var cart = new Cart((req.session.cart) ? req.session.cart : {});

		cart.remove(req.query._id);

		req.session.cart = cart;

		res.redirect('/cart.html');
	}
};