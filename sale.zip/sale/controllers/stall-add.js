var stallModel = require('../models/stall');

var ObjectId = require('mongodb').ObjectId;

module.exports = 
{
	index: function(req, res, next)
	{
		res.render('stall-add');
	},
	indexPost: function(req, res, next) 
	{
		console.log(req.body);

		var { name } = req.body;

		var errors = [];
		
		if(!name)
		{
			errors.push('You forget some fields :(');
		}

		if(errors.length > 0)
		{
			res.render('stall-add', 
			{
				errors: errors,
				values: req.body
			});
		}
		else
		{
			var newStall =
			{
				name: name,
				didDelete: false
			};
			stallModel.insertStall(newStall, function(result)
			{
				req.flash('success_msg', 'Inserted successful :)');

	            res.redirect('/stall-add.html');
			});
		}
	}
};