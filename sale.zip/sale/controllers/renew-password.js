var userModel = require('../models/user');
var bcrypt = require('bcryptjs');

module.exports =
{
	index: function(req, res, next)
	{
		res.render('renew-password');
	},
	indexPost: function(req, res, next)
	{
		console.log(req.body);
		
		var email = req.query.email;
		var { password1, password2 } = req.body;

		var errors = [];

		if(!password1 || !password2)
		{
			errors.push('You forget some fields :(');
		}
		if(password1 != password2)
		{
			errors.push('Your new password do not match :(');
		}
		if(password1.length <= 6)
		{
			errors.push('Your new password must be at least 7 characters :(');
		}

		if(errors.length > 0)
		{
			res.render('renew-password', 
			{
				errors: errors,
				values: req.body
			});
		}
		else
		{
			userModel.getListUserByQuery({ email: email }, function(users)
			{
				var user = users[0];

				bcrypt.genSalt(10, function(err, salt)
				{
			        bcrypt.hash(password1, salt, function(err, hash)
			        {
			            if (err) throw err;

			            userModel.updateUser({ email: email }, { $set: { password: hash } }, function(result)
						{
							req.flash('success_msg', 'Renew successful :)');

							res.redirect('/renew-password.html?email='+email);
						});
	        		});
	  			});
			});
		}
	}
};