var couponModel = require('../models/coupon');
var customerModel = require('../models/customer');
var orderModel = require('../models/order');
var orderDetailModel = require('../models/order-detail');

var Cart = require('../models/cart');

module.exports =
{
	index: function(req, res, next)
	{
		var cart = new Cart((req.session.cart) ? req.session.cart : {});
		
		res.render('checkout', 
		{
			storedItems: cart.generateArray(),
			totalPrice: cart.totalPrice,
			values: req.query
		});
	},
	checkCoupon: function(req, res, next)
	{
		if(req.query.code=='')
		{
			res.redirect('/checkout.html');
		}
		else
		{
			couponModel.getListCouponByQuery({ code: req.query.code }, function(coupons)
			{
				var discount = 0;
				if(coupons.length)
				{
					discount = coupons[0].discount;
				}

				req.flash('discount', discount);

				res.redirect('/checkout.html?code=' + req.query.code);
			});
		}
	},
	indexPost: function(req, res, next)
	{
		console.log(req.body);
		
		var { code, discount, name, phone, address, shipType} = req.body;

		var errors = [];

		var cart = new Cart((req.session.cart) ? req.session.cart : {});

		if(!name || !phone || !address || !shipType)
		{
			errors.push('You forget some fields :(');
		}

		if(errors.length > 0)
		{
			res.render('checkout', 
			{
				storedItems: cart.generateArray(),
				totalPrice: cart.totalPrice,
				errors: errors,
				values: req.body
			});
		}
		else
		{
			var newCustomer = 
			{
				email: req.user.email,
				name: name,
				phone: phone,
				address: address,
				didDelete: false
			}
			customerModel.insertCustomer(newCustomer, function(promise)
			{
				promise.then(function(result)
				{
					var shipCharge = 0;
					if(shipType=='veryFast')
					{
						shipCharge = 15;
					}
					if(shipType=='fast')
					{
						shipCharge = 10;
					}
					if(shipType=='normal')
					{
						shipCharge = 5;
					}

					var today = new Date();
					var dd = String(today.getDate()).padStart(2, '0');
					var mm = String(today.getMonth() + 1).padStart(2, '0');
					var yyyy = today.getFullYear();
					today = mm + '-' + dd + '-' + yyyy;

					console.log(result);

					var newOrder = 
					{
						customerId: ''+result.ops[0]._id,
						coupon: code,
						discount: parseInt(discount),
						shipCharge: shipCharge,
						total: cart.totalPrice + shipCharge - parseInt(discount),
						status: 'Chưa giao',
						orderDate: today,
						didDelete: false
					}
					orderModel.insertOrder(newOrder, function(promise)
					{
						promise.then(function(result)
						{
							var listOrderDetail = [];
							for(var storedItem of cart.generateArray())
							{
								var newOrderDetail = 
								{
									orderId: ''+result.ops[0]._id,
									productId: storedItem.item._id,
									qty: storedItem.qty,
									didDelete: false
								}
								listOrderDetail.push(newOrderDetail);
							}
							orderDetailModel.insertManyOrderDetail(listOrderDetail, function(promise)
							{
								promise.then(function(result)
								{
									res.redirect('confirmation.html?_id='+result.ops[0].orderId);
								});
							});
						});

					});
				});				
			});
		}
	}
};