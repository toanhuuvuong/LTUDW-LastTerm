var productModel = require('../models/product');

module.exports = 
{
	// -- Lấy top 10 sản phẩm mới nhất và phổ biến nhất
	index: function(req, res, next)
	{
		if (req.isAuthenticated()) 
	    {
	      req.flash('didLogin', 'true');
	    }
	    else
	    {
	      req.flash('didLogin', 'false');
	    }
		productModel.getListProductByQuery({}, function(products)
		{
			var top10LastestProduct = products.slice(0, 10);

			productModel.getListProductByQuery({}, function(products)
			{
				var top10MostPopularProduct = products.slice(0, 10);

				res.render('index', 
				{
					top10LastestProduct: top10LastestProduct,
					top10MostPopularProduct: top10MostPopularProduct
				});
			}, { numRate: -1 });

		}, { date: -1 });
	}
};