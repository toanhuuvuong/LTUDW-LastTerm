var baseQuery = require("./base-query");

module.exports = 
{
	// -- Thêm 1 khách hàng
	insertCustomer: function(newCustomer, callback)
	{
		baseQuery.insertDocument("Customer", newCustomer, callback)
	},
	// -- Lấy danh sách khách hàng theo câu truy vấn
	getListCustomerByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Customer", query, callback, options)
	}
};