var baseQuery = require("./base-query");

module.exports = 
{
	// -- Thêm 1 quản trị viên
	insertAdmin: function(newAdmin, callback)
	{
		baseQuery.insertDocument("Admin", newAdmin, callback)
	},
	// -- Lấy danh sách quản trị viên theo câu truy vấn
	getListAdminByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Admin", query, callback, options)
	}
};