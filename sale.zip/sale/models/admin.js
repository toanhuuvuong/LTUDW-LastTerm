var baseQuery = require("./base-query");

module.exports = 
{
	// -- Cập nhật 1 quản trị viên
	updateAdmin: function(query, newValue, callback)
	{
		baseQuery.updateDocument("Admin", query, newValue, callback)
	},
	// -- Thêm 1 quản trị viên
	insertAdmin: function(newAdmin, callback)
	{
		baseQuery.insertDocument("Admin", newAdmin, callback)
	},
	// -- Lấy danh sách quản trị viên theo câu truy vấn
	getListAdminByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Admin", query, callback, options)
	}
};