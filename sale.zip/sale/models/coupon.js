var baseQuery = require("./base-query");

module.exports = 
{
	// -- Cập nhật 1 phiếu giảm giá
	updateCoupon: function(query, newValue, callback)
	{
		baseQuery.updateDocument("Coupon", query, newValue, callback)
	},
	// -- Thêm 1 phiếu giảm giá
	insertCoupon: function(newCoupon, callback)
	{
		baseQuery.insertDocument("Coupon", newCoupon, callback)
	},
	// -- Lấy danh sách phiếu giảm giá theo câu truy vấn
	getListCouponByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Coupon", query, callback, options)
	}
};