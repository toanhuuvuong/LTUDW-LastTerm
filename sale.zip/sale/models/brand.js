var baseQuery = require("./base-query");

module.exports = 
{
	// -- Thêm 1 nhãn hiệu
	insertBrand: function(newBrand, callback)
	{
		baseQuery.insertDocument("Brand", newBrand, callback)
	},
	// -- Lấy danh sách nhãn hiệu theo câu truy vấn
	getListBrandByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Brand", query, callback, options)
	}
};