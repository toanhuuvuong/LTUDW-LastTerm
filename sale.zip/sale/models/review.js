var baseQuery = require("./base-query");

module.exports = 
{
	// -- Thêm 1 đánh giá
	insertReview: function(newReview, callback)
	{
		baseQuery.insertDocument("Review", newReview, callback)
	},
	// -- Lấy danh sách đánh giá theo câu truy vấn
	getListReviewByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Review", query, callback, options)
	}
};