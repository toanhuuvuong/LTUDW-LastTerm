var baseQuery = require("./base-query");

module.exports = 
{
	// -- Thêm 1 sản phẩm
	insertProduct: function(newProduct, callback)
	{
		baseQuery.insertDocument("Product", newProduct, callback)
	},
	// -- Lấy danh sách sản phẩm theo câu truy vấn
	getListProductByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("Product", query, callback, options)
	}
};