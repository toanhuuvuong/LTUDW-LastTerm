var baseQuery = require("./base-query");

module.exports = 
{
	// -- Thêm 1 chi tiết đơn hàng
	insertOrderDetail: function(newOrderDetail, callback)
	{
		baseQuery.insertDocument("OrderDetail", newOrderDetail, callback)
	},
	insertManyOrderDetail: function(listOrderDetail, callback)
	{
		baseQuery.insertManyDocument("OrderDetail", listOrderDetail, callback)
	},
	// -- Lấy danh sách chi tiết đơn hàng theo câu truy vấn
	getListOrderDetailByQuery: function(query, callback, options = {})
	{
		baseQuery.getListDocument("OrderDetail", query, callback, options)
	}
};