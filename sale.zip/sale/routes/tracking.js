var express = require('express');
var controller = require("../controllers/tracking.js");
var authentication = require('../config/authentication');

var router = express.Router();

/* GET tracking page. */
router.get('/', authentication.checkLoginStatus, controller.index);

module.exports = router;