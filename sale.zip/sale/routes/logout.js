var express = require('express');

var router = express.Router();

router.get('/', function(req, res) 
{
	if(process.env.LOGIN_TYPE == 'admin')
	{
		process.env.DID_LOGIN_ADMIN = 'FALSE';
	}
	if(process.env.LOGIN_TYPE == 'customer')
	{
		process.env.DID_LOGIN = 'FALSE';
    }

	req.logout();

	req.flash('success_msg', 'You are logged out :)');
	
	res.redirect('login.html');
});

module.exports = router;