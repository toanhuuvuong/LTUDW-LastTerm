var express = require('express');
var controller = require("../controllers/forgot-password.js");
var authentication = require('../config/authentication');

var router = express.Router();

/* GET forgot-password page. */
router.get('/', authentication.checkLoginStatus, controller.index);

/* GET forgot-password/change-password page. */
router.get('/change-password page/', authentication.checkLoginStatus, controller.changePassword);

/* POST forgot-password page. */
router.post('/', controller.indexPost);

/* POST forgot-password/change-password page. */
router.post('/change-password page/', controller.changePasswordPost);

module.exports = router;