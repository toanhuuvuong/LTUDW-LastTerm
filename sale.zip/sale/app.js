require('dotenv').config();

var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var passport = require('passport');
var flash = require('connect-flash');
var session = require('express-session');

var MongoStore = require('connect-mongo')(session);

var indexRouter = require('./routes/index');
var shoesStallRouter = require('./routes/shoes-stall')
var singleProductRouter = require('./routes/single-product');
var checkoutRouter = require('./routes/checkout');
var cartRouter = require('./routes/cart');
var confirmationRouter = require('./routes/confirmation');
var loginRouter = require('./routes/login');
var forgotPasswordRouter = require('./routes/forgot-password');
var renewPasswordRouter = require('./routes/renew-password');
var registrationRouter = require('./routes/registration');
var trackingRouter = require('./routes/tracking');
var contactRouter = require('./routes/contact');
var logoutRouter = require('./routes/logout');
var updateUserInfoRouter = require('./routes/update-user-info');
var updateUserPasswordRouter = require('./routes/update-user-password');
var searchRouter = require('./routes/search');

var homeRouter = require('./routes/home');
var accountListRouter = require('./routes/account-list');
var accountEditRouter = require('./routes/account-edit');
var stallListRouter = require('./routes/stall-list');
var stallEditRouter = require('./routes/stall-edit');
var stallAddRouter = require('./routes/stall-add');
var brandListRouter = require('./routes/brand-list');
var brandEditRouter = require('./routes/brand-edit');
var brandAddRouter = require('./routes/brand-add');
var productListRouter = require('./routes/product-list');
var productEditRouter = require('./routes/product-edit');
var productAddRouter = require('./routes/product-add');
var top10ProductRouter = require('./routes/top-10-product');
var top10ProductOfShopRouter = require('./routes/top-10-product-of-shop');
var top10ProductOfStallRouter = require('./routes/top-10-product-of-stall');
var orderListRouter = require('./routes/order-list');
var orderEditRouter = require('./routes/order-edit');
var revenueRouter = require('./routes/revenue');
var revenueStatisticsRouter = require('./routes/revenue-statistics');
var loginAdminRouter = require('./routes/login-admin');
var registrationAdminRouter = require('./routes/registration-admin');
var updateAdminInfoRouter = require('./routes/update-admin-info');

var app = express();

// passport config
require('./config/passport')(passport);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// express session
app.use(session(
{
	secret: 'secret',
	resave: true,
	saveUninitialized: true,
	store: new MongoStore(
	{ 
		url: 'mongodb+srv://toanhuuvuong:toanhuuvuong123456@toandb-lttzl.azure.mongodb.net/test?retryWrites=true&w=1/' }
	),
	cookie: { maxAge: 180 * 60 * 1000 }
}));

// passport middleware
app.use(passport.initialize());
app.use(passport.session());

// connect flash
app.use(flash());

// global variables
app.use(function(req, res, next) 
{
	res.locals.success_msg = req.flash('success_msg');
	res.locals.error_msg = req.flash('error_msg');
	res.locals.error = req.flash('error');
	res.locals.discount = req.flash('discount');
	res.locals.session = req.session;
	next();
});

// routers
app.use('/', indexRouter);
app.use('/index.html', indexRouter);
app.use('/shoes-stall.html', shoesStallRouter);
app.use('/single-product.html', singleProductRouter);
app.use('/checkout.html', checkoutRouter);
app.use('/cart.html', cartRouter);
app.use('/confirmation.html', confirmationRouter);
app.use('/login.html', loginRouter);
app.use('/forgot-password.html', forgotPasswordRouter);
app.use('/renew-password.html', renewPasswordRouter);
app.use('/registration.html', registrationRouter);
app.use('/tracking.html', trackingRouter);
app.use('/contact.html', contactRouter);
app.use('/logout.html', logoutRouter);
app.use('/update-user-info.html', updateUserInfoRouter);
app.use('/update-user-password.html', updateUserPasswordRouter);
app.use('/search.html', searchRouter);

app.use('/home.html', homeRouter);
app.use('/account-list.html', accountListRouter);
app.use('/account-edit.html', accountEditRouter);
app.use('/stall-list.html', stallListRouter);
app.use('/stall-edit.html', stallEditRouter);
app.use('/stall-add.html', stallAddRouter);
app.use('/brand-list.html', brandListRouter);
app.use('/brand-edit.html', brandEditRouter);
app.use('/brand-add.html', brandAddRouter);
app.use('/product-list.html', productListRouter);
app.use('/product-edit.html', productEditRouter);
app.use('/product-add.html', productAddRouter);
app.use('/top-10-product.html', top10ProductRouter);
app.use('/top-10-product-of-shop.html', top10ProductOfShopRouter);
app.use('/top-10-product-of-stall.html', top10ProductOfStallRouter);
app.use('/order-list.html', orderListRouter);
app.use('/order-edit.html', orderEditRouter);
app.use('/revenue.html', revenueRouter);
app.use('/revenue-statistics.html', revenueStatisticsRouter);
app.use('/login-admin.html', loginAdminRouter);
app.use('/registration-admin.html', registrationAdminRouter);
app.use('/update-admin-info.html', updateAdminInfoRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) 
{
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) 
{
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
